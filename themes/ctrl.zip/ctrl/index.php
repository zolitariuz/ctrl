<?php

	get_header();

	get_template_part( 'templates/ctrl', 'servicios' );
	get_template_part( 'templates/ctrl', 'portafolio' );
	get_template_part( 'templates/ctrl', 'clientes' );
	get_template_part( 'templates/ctrl', 'planta' );
	get_template_part( 'templates/ctrl', 'nosotros' );
	get_template_part( 'templates/ctrl', 'contacto' );

	get_footer();

?>