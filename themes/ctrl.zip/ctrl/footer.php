	
	<footer></footer>
		<?php wp_footer(); ?>
		</div><!-- container -->
	</body>

</html>
